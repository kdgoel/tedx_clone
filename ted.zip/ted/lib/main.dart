import 'package:flutter/material.dart';
import 'package:td/frontPage.dart';

void main() => runApp(MaterialApp(
      home: Front(),
    ));
